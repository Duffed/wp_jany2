<p><strong>
<?php _e('For more information:', PostSnippets::TEXT_DOMAIN); ?>
</strong></p>

<p><a href="http://johansteen.se/code/post-snippets/" target="_blank"><?php
_e('Documentation', PostSnippets::TEXT_DOMAIN);
?></a></p>

<p><a href="http://wordpress.org/support/plugin/post-snippets" target="_blank"><?php
_e('Support Forums', PostSnippets::TEXT_DOMAIN);
?></a></p>

<p><a href="https://github.com/artstorm/post-snippets" target="_blank"><?php
_e('GitHub Contribution', PostSnippets::TEXT_DOMAIN);
?></a></p>
