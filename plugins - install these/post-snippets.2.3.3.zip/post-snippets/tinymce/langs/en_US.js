tinyMCE.addI18n({en_US:{
post_snippets:{	
desc : 'Insert a Post Snippet'
}}});